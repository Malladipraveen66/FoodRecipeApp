import { Card } from "@mui/material";
import { blueGrey } from "@mui/material/colors";
import React, { useState, useEffect } from "react";

function RandomUser() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "https://randomuser.me/api/?page=1&results=1&seed=abc"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch user");
        }
        const data = await response.json();
        setUser(data.results[0]);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching user:", error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      {loading ? (
        <div>Loading...</div>
      ) : (
        <Card
          sx={{
            top:100,
            left:100,
            width: 250,
            backgroundColor: "rgb(250, 250, 250)",
            padding: "10px",
            position: "relative",
            right: 1,
            border:2,blueGrey
          }}
        >
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <img src={user.picture.large} alt="User" />
            <div>
              <div>
                {user.name.first} {user.name.last} 
              </div>
              <div>
                <p></p>
                <p></p>
                {user.gender}
                <p></p>
                <p></p>
              </div>
              <div>{user.phone}</div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

export default RandomUser;